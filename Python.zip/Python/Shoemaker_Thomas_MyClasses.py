"""Make nextRow() in each row sequence"""
from karel.robota import East
from karel.robota import West
from karel.robota import North
from karel.robota import South
from karel.robota import infinity
from karel.robota import window
from karel.robota import world
from karel.robota import UrRobot
#------------My Classes------------

#------------Climber Class------------
class Climber(UrRobot):
    def turn(self, a):
        for i in range(a):
            self.turnLeft()
    def climbStep(self, a):
        for i in range(a):
            #Must be facing north at bottom of step
            self.move()
            self.turn(3)
            self.move()
            self.turn(1)
#------------Dancer Class------------
class Dancer(UrRobot):
    def pickBeeperNum(self, a):
        for i in range(a):
            self.pickBeeper()
    def turnRight(self):
        self.turnLeft()
        self.turnLeft()
        self.turnLeft()
    def turnAround(self):
        self.turnLeft()
        self.turnLeft()
    def spin(self):
        self.turnAround()
        self.turnAround()
    def backUp(self, a):
        for i in range(a):
            self.turnAround()
            self.move()
            self.turnAround()
    def slideRight(self, a):
        for i in range(a):
            self.turnRight()
            self.move()
            self.turnLeft()
    def slideLeft(self, a):
        for i in range(a):
            self.turnLeft()
            self.move()
            self.turnRight()
    def dance(self, a):
        self.move()
        self.backUp(2)
        self.move()
        self.slideLeft(1)
        self.slideRight(2)
        self.slideLeft(1)
        self.slideRight(1)
        self.slideLeft(1)
    def partnerDance(self, a):
        self.backUp(1)
        self.move()
        self.move()
        self.backUp(1)
        self.slideRight(1)
        self.slideLeft(2)
        self.slideRight(1)
        self.slideLeft(1)
        self.slideRight(1)
    def danceSteps1(self):
        self.move()
        self.pickBeeper()
        self.backUp(1)
        self.slideLeft(1)
        self.backUp(1)
        self.pickBeeper()
        self.move()
        self.slideRight(2)
        self.backUp(1)
        self.pickBeeper()
        self.move()
        self.slideLeft(1)
        self.pickBeeper()
    def danceSteps2(self):
        self.move()
        self.slideLeft(1)
        self.pickBeeper()
        self.slideRight(2)
        self.pickBeeper()
        self.slideLeft(1)
        self.backUp(2)
        self.slideLeft(1)
        self.pickBeeper()
        self.slideRight(2)
        self.pickBeeper()
        self.slideLeft(1)
        self.move()
        self.pickBeeper()
#----------------Writer Class ------------------------------
class Writer(Dancer):
    """All methods in this class assume Writer is in the bottom 
    left of letter and pointing East. All methods line writes should
    make the robot move 5 avenues across.
    All letters have a width of 5 avenues and a height of 5 streets"""

    def bigMove(self, a):
        #Moves 'a' times
        for i in range(a):
            self.move()

    def putMove(self, a):
        #Puts beeper and moves
        for i in range(a):
            self.putBeeper()
            self.move()

    def xxxxx(self):
        self.putMove(5)

    def xxxx_(self):
        self.putMove(4)

    def x_xxx(self):
        self.putMove(1)
        self.move()
        self.putMove(3)

    def xxx__(self):
        self.putMove(3)
        self.bigMove(2)

    def x___x(self):
        self.putMove(1)
        self.bigMove(3)
        self.putMove(1)
        
        
    def x__x_(self):
        self.putMove(1)
        self.bigMove(2)
        self.putMove(1)
        self.move()

    def _x_x_(self):
        self.move()
        self.putMove(1)
        self.move()
        self.putMove(1)
        self.move()

    def x_x__(self):
        self.putMove(1)
        self.move()
        self.putMove(1)
        self.bigMove(2)

    def x____(self):
        self.putMove(1)
        self.bigMove(4)

    def __x__(self):
        self.bigMove(2)
        self.putMove(1)
        self.bigMove(2)
        self.nextRow()

    def ____x(self):
        self.bigMove(4)
        self.putMove()
        self.nextRow()
        

    def nextRow(self):
        '''Robot must be one avenue further than last beeper placed and facing East.
        Robot should end up one corner North, five corners West, facing East'''
        self.turnLeft()
        self.move()
        self.turnLeft()
        self.bigMove(5)
        self.turnLeft()
        self.turnLeft()

    def nextLetter(self):
        '''Assumes robot position is one corner to the East of top right corner of
        letter and facing East. Must end up 2 corners East of previous letter and
        at the bottom to be in position to start at the bottom left of the new letter'''
        self.move()
        self.turnRight()
        self.bigMove(4)
        self.turnLeft()


    """----------LETTERS----------"""
    def a(self):
        self.x___x()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.xxxxx()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.xxxxx()
        self.nextLetter()
    def b(self):
        self.xxxx_()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.xxxx_()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.xxxx_()
        self.nextLetter()
    def c(self):
        self.xxxxx()
        self.nextRow()
        self.x____()
        self.nextRow()
        self.x____()
        self.nextRow()
        self.x____()
        self.nextRow()
        self.xxxxx()
        self.nextLetter()
    def d(self):
        self.xxxx_()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.x___x()
        self.nextRow()
        self.xxxx_()
        self.nextLetter()
    def e(self):
        self.xxxxx()
        self.nextRow()
        self.x____()
        self.nextRow()
        self.xxxx_()
        self.nextRow()
        self.x____()
        self.nextRow()
        
