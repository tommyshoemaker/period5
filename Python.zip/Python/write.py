#
# 
#


# Important preamble: keep in all karel programs
from karel.robota import East
from karel.robota import West
from karel.robota import North
from karel.robota import South
from karel.robota import infinity
from karel.robota import window
from karel.robota import world
from karel.robota import UrRobot
from Shoemaker_Thomas_MyClasses import Writer

# The Karel task block  
def task():
        #Commands to control the "world"
        
        world.setSize(30,30)               # set the size of the visible world
        world.setDelay(50)                # set simulation speed. 0-fastest, 100-slowest

        
        
        #Write the code to test the methods of Dancer Class with different robots
        sb2 = Writer(1,1,East, infinity)

        #Write the letter H
        sb2.x___x()
        sb2.nextRow()
        sb2.x___x()
        sb2.nextRow()
        sb2.xxxxx()
        sb2.nextRow()
        sb2.x___x()
        sb2.nextRow()
        sb2.x___x()

        #Position robot to write next letter
        sb2.nextLetter()
        #Write the letter I
        
 
# Important epilogue: keep in all karel programs    
if __name__ == '__main__':
        window().run(task)
    
